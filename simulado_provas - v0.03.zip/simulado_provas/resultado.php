<?php
include 'conexao.php';

$total_acertos = 0;

foreach ($_POST as $questao_id => $resposta_usuario) {
    $questao_id = str_replace('questao_', '', $questao_id);
    $sql = "SELECT resposta_correta FROM questoes WHERE id = $questao_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['resposta_correta'] == $resposta_usuario) {
            $total_acertos++;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado do Simulado</title>
</head>
<body>
    <h1>Resultado</h1>
    <p>Você acertou <?php echo $total_acertos; ?> de 60 questões.</p>
</body>
</html>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulado</title>
</head>
<body>
    <h1>Responda as questões abaixo</h1>
    <form action="resultado.php" method="post">
        <!-- As questões serão inseridas aqui via PHP -->
        <?php
        include 'conexao.php';

        // Verifica se a conexão foi bem-sucedida
        if ($conn === false) {
            die("Erro na conexão com o banco de dados: " . mysqli_connect_error());
        }

        // Buscando 60 questões aleatórias do banco de dados
        $sql = "SELECT * FROM questoes ORDER BY RAND() LIMIT 60";
        $result = $conn->query($sql);

        // Verifica se houve um erro na execução da consulta
        if ($result === false) {
            die("Erro na consulta SQL: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            $index = 1;
            while ($row = $result->fetch_assoc()) {
                // Armazena as alternativas em um array
                $alternativas = [
                    'A' => htmlspecialchars($row['opcao_a']),
                    'B' => htmlspecialchars($row['opcao_b']),
                    'C' => htmlspecialchars($row['opcao_c']),
                    'D' => htmlspecialchars($row['opcao_d']),
                ];

                // Embaralha as alternativas
                $keys = array_keys($alternativas);
                shuffle($keys);

                echo "<div>";
                echo "<p><strong>Questão " . $index . ":</strong> " . htmlspecialchars($row['enunciado']) . "</p>";

                // Exibe as alternativas embaralhadas
                foreach ($keys as $key) {
                    echo "<input type='radio' name='questao_" . $row['id'] . "' value='" . $key . "'> " . $alternativas[$key] . "<br>";
                }

                echo "</div><br>";
                $index++;
            }
        } else {
            echo "Nenhuma questão encontrada.";
        }

        $conn->close();
        ?>
        <input type="submit" value="Finalizar e Ver Resultado">
    </form>
</body>
</html>

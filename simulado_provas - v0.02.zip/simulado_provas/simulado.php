<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulado</title>
</head>
<body>
	<!-- para quem disse que faltou comentário, toma comentário -->
    <h1>Responda as questões abaixo</h1>
    <form action="resultado.php" method="post">
        <!-- Fazer futuramente uma DIV aqui para ficar mais bonito é pra começar aqui -->
        <?php
        include 'conexao.php';
        if ($conn === false) {
            die("Erro na conexão com o banco de dados: " . mysqli_connect_error());
        }

        // Essa função de select aqui é para buscar 60 questões aleatórias do banco de dados e exibir como se fosse um randomizer
        $sql = "SELECT * FROM questoes ORDER BY RAND() LIMIT 60";
        $result = $conn->query($sql);

        if ($result === false) {
            die("Erro na consulta SQL: " . $conn->error);
        }

		// daqui para baixo ficam as respostas, penso em fazer div separada para cada pergunta, mas isso é para o futuro
        if ($result->num_rows > 0) {
            $index = 1;
            while($row = $result->fetch_assoc()) {
                echo "<div>";
                echo "<p><strong>Questão " . $index . ":</strong> " . htmlspecialchars($row['enunciado']) . "</p>";
                echo "<input type='radio' name='questao_" . $row['id'] . "' value='A'> " . htmlspecialchars($row['opcao_a']) . "<br>";
                echo "<input type='radio' name='questao_" . $row['id'] . "' value='B'> " . htmlspecialchars($row['opcao_b']) . "<br>";
                echo "<input type='radio' name='questao_" . $row['id'] . "' value='C'> " . htmlspecialchars($row['opcao_c']) . "<br>";
                echo "<input type='radio' name='questao_" . $row['id'] . "' value='D'> " . htmlspecialchars($row['opcao_d']) . "<br>";
                echo "</div><br>";
                $index++;
            }
        } else {
            echo "Nenhuma questão encontrada.";
        }

        $conn->close();
        ?>
        <input type="submit" value="Finalizar e Ver Resultado">
    </form>
</body>
</html>

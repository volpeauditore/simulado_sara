<?php
$servername = "localhost";  // Geralmente "localhost" para servidores locais
$username = "root";          // Seu nome de usuário do MySQL
$password = "";              // Sua senha do MySQL (se houver)
$dbname = "prova";  // Nome do banco de dados que você criou

// Criando a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// echo "Conexão bem-sucedida";
?>
